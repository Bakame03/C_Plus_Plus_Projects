#ifndef __LISTOFSTRINGS_HPP__
#define __LISTOFSTRINGS_HPP__

#include <iostream>
#include <string>

class ListOfStrings
{
    private:
        class StringNode
        {
            public:
                std::string value;
                StringNode* next;
                StringNode(std::string, StringNode* = nullptr);
                StringNode(const StringNode&);
                ~StringNode();
        };
        size_t count;
        StringNode* first;
        StringNode* last;
        void push_front(StringNode* node);
        void push_back(StringNode* node);
        void insert_sorted(StringNode* node);
        

    public:
        ListOfStrings();
        ListOfStrings(const ListOfStrings&);
        ~ListOfStrings();
        inline size_t size() const { return count; };
        const std::string& front() const;
        const std::string& back() const;
        void push_front(std::string str);
        void push_back(std::string str);
        void pop_front();
        void pop_back();
        void clear();
        void splice(ListOfStrings& other);
        void reverse();
        void insert_sorted(std::string str);
        void sort();
        friend std::ostream& operator<<(std::ostream& os, const ListOfStrings& liste);
        

};

#endif
